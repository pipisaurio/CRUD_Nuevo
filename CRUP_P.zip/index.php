<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Estudiantes y Cursos</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center">Listado de Estudiantes y Cursos</h1>

        <!-- Enlaces para crear nuevos registros -->
        <div class="mb-4">
            <a href="crear.php" class="btn btn-primary">Crear Estudiante y Curso</a>
            <a href="inscribir.php" class="btn btn-secondary">Inscribir Estudiante en Curso</a>
        </div>

        <!-- Listado de estudiantes -->
        <h2>Estudiantes</h2>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Email</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php
                include 'db.php';
                $sql = "SELECT * FROM estudiantes";
                $result = $conn->query($sql);
                while($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>".$row['id']."</td>
                            <td>".$row['nombre']."</td>
                            <td>".$row['email']."</td>
                            <td>
                                <a href='editar_estudiante.php?id=".$row['id']."' class='btn btn-warning btn-sm'>Editar</a>
                                <a href='eliminar_estudiante.php?id=".$row['id']."' class='btn btn-danger btn-sm' onclick=\"return confirm('¿Estás seguro de eliminar este estudiante?');\">Eliminar</a>
                            </td>
                          </tr>";
                }
                ?>
            </tbody>
        </table>

        <!-- Listado de cursos -->
        <h2>Cursos</h2>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Descripción</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT * FROM cursos";
                $result = $conn->query($sql);
                while($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>".$row['id']."</td>
                            <td>".$row['nombre']."</td>
                            <td>".$row['descripcion']."</td>
                            <td>
                                <a href='editar_curso.php?id=".$row['id']."' class='btn btn-warning btn-sm'>Editar</a>
                                <a href='eliminar_curso.php?id=".$row['id']."' class='btn btn-danger btn-sm' onclick=\"return confirm('¿Estás seguro de eliminar este curso?');\">Eliminar</a>
                            </td>
                          </tr>";
                }
                ?>
            </tbody>
        </table>

        <!-- Listado de inscripciones -->
        <h2>Inscripciones</h2>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Estudiante</th>
                    <th>Curso</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT estudiantes.nombre AS estudiante, cursos.nombre AS curso, inscripciones.estudiante_id, inscripciones.curso_id
                        FROM inscripciones
                        INNER JOIN estudiantes ON inscripciones.estudiante_id = estudiantes.id
                        INNER JOIN cursos ON inscripciones.curso_id = cursos.id";
                $result = $conn->query($sql);
                while($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>".$row['estudiante']."</td>
                            <td>".$row['curso']."</td>
                            <td>
                                <a href='eliminar_inscripcion.php?estudiante_id=".$row['estudiante_id']."&curso_id=".$row['curso_id']."' class='btn btn-danger btn-sm' onclick=\"return confirm('¿Estás seguro de eliminar esta inscripción?');\">Eliminar</a>
                            </td>
                          </tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
