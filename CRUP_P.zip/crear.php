<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crear Estudiante y Curso</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center">Crear Estudiante y Curso</h1>

        <div class="row">
            <!-- Formulario para crear estudiantes -->
            <div class="col-md-6">
                <h2>Nuevo Estudiante</h2>
                <form action="guardar_estudiante.php" method="POST">
                    <div class="form-group">
                        <label for="nombre">Nombre del Estudiante</label>
                        <input type="text" name="nombre" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="email">Correo Electrónico</label>
                        <input type="email" name="email" class="form-control" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Crear Estudiante</button>
                </form>
            </div>

            <!-- Formulario para crear cursos -->
            <div class="col-md-6">
                <h2>Nuevo Curso</h2>
                <form action="guardar_curso.php" method="POST">
                    <div class="form-group">
                        <label for="nombre">Nombre del Curso</label>
                        <input type="text" name="nombre" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="descripcion">Descripción</label>
                        <textarea name="descripcion" class="form-control" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Crear Curso</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
