<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscribir Estudiante en Curso</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center">Inscribir Estudiante en Curso</h1>

        <form action="guardar_inscripcion.php" method="POST">
            <div class="form-group">
                <label for="estudiante_id">Seleccionar Estudiante</label>
                <select name="estudiante_id" class="form-control" required>
                    <option value="">Seleccionar estudiante</option>
                    <?php
                    include 'db.php';
                    $sql = "SELECT * FROM estudiantes";
                    $result = $conn->query($sql);
                    while($row = $result->fetch_assoc()) {
                        echo "<option value='".$row['id']."'>".$row['nombre']."</option>";
                    }
                    ?>
                </select>
            </div>

            <div class="form-group">
                <label for="curso_id">Seleccionar Curso</label>
                <select name="curso_id" class="form-control" required>
                    <option value="">Seleccionar curso</option>
                    <?php
                    $sql = "SELECT * FROM cursos";
                    $result = $conn->query($sql);
                    while($row = $result->fetch_assoc()) {
                        echo "<option value='".$row['id']."'>".$row['nombre']."</option>";
                    }
                    ?>
                </select>
            </div>

            <button type="submit" class="btn btn-primary">Inscribir</button>
        </form>
    </div>
</body>
</html>
