<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nombre = $_POST['nombre'];
    $email = $_POST['email'];

    $sql = "INSERT INTO estudiantes (nombre, email) VALUES ('$nombre', '$email')";

    if ($conn->query($sql) === TRUE) {
        echo "Estudiante creado correctamente";
    } else {
        echo "Error: " . $conn->error;
    }

    $conn->close();
    header('Location: index.php');
}
?>
