<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $estudiante_id = $_POST['estudiante_id'];
    $curso_id = $_POST['curso_id'];

    $sql = "INSERT INTO inscripciones (estudiante_id, curso_id) VALUES ('$estudiante_id', '$curso_id')";

    if ($conn->query($sql) === TRUE) {
        echo "Inscripción realizada correctamente";
    } else {
        echo "Error: " . $conn->error;
    }

    $conn->close();
    header('Location: index.php');
}
?>
